
<footer>
 
   <div class="footermb">
      <ul class="container">
         <li class="weba">
<div class="footer_creared"><a href="index.php" rel="dofollow" target="_blank" title="Kora Now">Kora Now</a></div>
         </li>
        <li id="menu-item-2498" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2498"><a href="index.php">Kora Now  </a></li>
<li id="menu-item-4501" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4501"><a href="contact.php">إتصل بنا</a></li>
<li id="menu-item-4503" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4503"><a rel="privacy-policy" href="privacy-policy.php">سياسة الخصوصية</a></li>
      </ul>
   </div>
</footer>